Default implementation of memory and mysql controllers. To copy in the framework subfolder.
