BZlib Library based on http://elj.sourceforge.net/ 

Windows:
At the moment the library does not work on windows.
Linking issues.

Error: for each exported function in libbz2.lib.
Cobj1.lib(big_file_C1_c.obj) : error LNK2019: unresolved external symbol BZ2_bzCompressInit referenced in function F19_456
