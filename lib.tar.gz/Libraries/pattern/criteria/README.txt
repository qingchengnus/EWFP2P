This lib provides an implementation for the Filter|Criteria pattern.

note: it is using the term "criteria" instead of more correct term "criterion", mainly to match existing known criteria pattern interfaces.